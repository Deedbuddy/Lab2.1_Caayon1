package com.sportsapp.ui.sports

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sportsapp.R
import com.sportsapp.adapter.SportsAdapter
import com.sportsapp.model.Sport

class MySportsFragment : Fragment() {

    private lateinit var sportsGrid: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_my_sports, container, false)
        sportsGrid = view.findViewById(R.id.sports_grid)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupSportsGrid()
    }

    private fun setupSportsGrid() {
        val sports = listOf(
            Sport("Football", R.drawable.ic_football, R.id.action_mySports_to_football),
            Sport("Basketball", R.drawable.ic_basketball, R.id.action_mySports_to_basketball),
            Sport("Tennis", R.drawable.ic_tennis, R.id.action_mySports_to_tennis),
            Sport("Swimming", R.drawable.ic_swimming, R.id.action_mySports_to_swimming)
        )

        val adapter = SportsAdapter(sports) { sport ->
            findNavController().navigate(sport.actionId)
        }

        sportsGrid.layoutManager = GridLayoutManager(requireContext(), 2)
        sportsGrid.adapter = adapter
    }
}